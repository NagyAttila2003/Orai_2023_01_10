<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cipohirdetesek', function (Blueprint $table) {
            $table->id("azon");
            $table->string("gyarto",12);
            $table->string("nev",12);
            $table->string("szin",12);
            $table->string("nem",5);
            $table->integer("meret");
            $table->integer("ar");
            $table->dateTime("lejarat");
            $table->integer("aktiv");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cipohirdetesek');
    }
};
